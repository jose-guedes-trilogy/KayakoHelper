/* src/background/createFolderBg.ts */


// Removed since native messaging is turned off